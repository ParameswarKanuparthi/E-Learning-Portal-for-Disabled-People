    <!-- <!DOCTYPE html>
<html>
<head>
    <title>Startup</title>
    <link rel="stylesheet" type="text/css" href="style3.css">
    <script type="text/javascript">
        function my(d) {
            // body...
            
            alert("nvhm");
        }
    </script>
</head>
<body>
<div id="header">
<img src="logo.png" id="logo">
<h1 id="title" tabindex="1" onkeyup="my('title');">GRAV INSTITUTIONS</h1>  

</div>
<div class="container" >
    <div id="leftcolumn">
        <div id="menu"> 
            <div id="empty"></div>

                <div id="dedulog" >
                    <a href="startup_stu_login.php" tabindex="2.1" >Student Login</a></div>
                
                <div id="teacherlog" >
                    <a href="teacherlog.php" tabindex="2.2"  >Teacher Login</a></div>
                
                <div id="studentsignup" >
                    <a href="startup_stu_sign.php" tabindex="2.3">Student signup</a></div>

                <div id="teachersignup" >
                    <a href="startup_teach_sign.php" tabindex="2.4"  >Teacher signup</a></div>
                
                <div id="admin" >
                    <a href="adminlog.php" tabindex="2.5">Admin Login</a></div>
                
        </div>
    </div>
    <div id="column">
       
</div> -->

<!-- <div id="bottom">
    <a href="about.html">ABOUT US</a><br><br>
    <a href="contact.html" id="contact">CONTACT US</a>
</div> -->

<!-- </body>
</html> -->



<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Startup Page</title>
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'><link rel="stylesheet" href="sidebar/style.css">
<link rel="stylesheet" type="text/css" href="style3.css">
<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<!-- partial:index.partial.html -->
<div class="container-fluid p-0">
  
<!-- Bootstrap row -->
<div class="row" id="body-row">
    <!-- Sidebar -->
    <div id="sidebar-container" class="sidebar-expanded d-none d-md-block"><!-- d-* hiddens the Sidebar in smaller devices. Its itens can be kept on the Navbar 'Menu' -->
        <!-- Bootstrap List Group -->
        <ul class="list-group">
            <!-- Separator with title -->
            <li class="list-group-item sidebar-separator-title text-muted d-flex align-items-center menu-collapsed">
                <small>MAIN MENU</small>
            </li>
            <!-- /END Separator -->
            <!-- Menu with submenu -->
            <a href="index.html" class="bg-dark list-group-item list-group-item-action">
                <div class="d-flex w-100 justify-content-start align-items-center">
                    <span class="fa fa-tasks fa-fw mr-3"></span>
                    <span class="menu-collapsed">Home</span>    
                </div>
            </a>
            <a href="#submenu1" data-toggle="collapse" aria-expanded="false" class="bg-dark list-group-item list-group-item-action flex-column align-items-start">
                <div class="d-flex w-100 justify-content-start align-items-center">
                    <span class="fa fa-dashboard fa-fw mr-3"></span> 
                    <span class="menu-collapsed">Teacher</span>
                    <span class="submenu-icon ml-auto"></span>
                </div>
            </a>
            <!-- Submenu content -->
            <div id='submenu1' class="collapse sidebar-submenu">
                <a href="teacherlog.php" class="list-group-item list-group-item-action bg-dark text-white">
                    <span class="menu-collapsed">Teacher Login</span>
                </a>
                <a href="startup_teach_sign.php" class="list-group-item list-group-item-action bg-dark text-white">
                    <span class="menu-collapsed">Teacher Signup</span>
                </a>
            </div>
            <a href="#submenu2" data-toggle="collapse" aria-expanded="false" class="bg-dark list-group-item list-group-item-action flex-column align-items-start">
                <div class="d-flex w-100 justify-content-start align-items-center">
                    <span class="fa fa-user fa-fw mr-3"></span>
                    <span class="menu-collapsed">Student</span>
                    <span class="submenu-icon ml-auto"></span>
                </div>
            </a>
            <!-- Submenu content -->
            <div id='submenu2' class="collapse sidebar-submenu">
                <a href="startup_stu_login.php" class="list-group-item list-group-item-action bg-dark text-white">
                    <span class="menu-collapsed">Student Login</span>
                </a>
                <a href="startup_stu_sign.php " class="list-group-item list-group-item-action bg-dark text-white">
                    <span class="menu-collapsed">Student Signup</span>
                </a>
            </div>            
            <a href="adminlog.php" class="bg-dark list-group-item list-group-item-action">
                <div class="d-flex w-100 justify-content-start align-items-center">
                    <span class="fa fa-tasks fa-fw mr-3"></span>
                    <span class="menu-collapsed">Admin Login</span>    
                </div>
            </a>
           
    </div><!-- sidebar-container END -->

    <!-- MAIN -->
    <div class="col">

    <div id="header">
<img src="logo.png" id="logo">
<h1 id="title" tabindex="1">GRAV INSTITUTIONS</h1>  

</div>
<div class="container" >

<div id="midcolumn">
        <br>
        <div class="course"><h1>Internet of Things</h1>
        <p>Human–computer interaction (HCI) researches the design and use of computer technology, focused on the interfaces between people (users) and computers. Researchers in the field of HCI both observe the ways in which humans interact with computers and design technologies that let humans interact with computers in novel ways. As a field of research, human–computer interaction is situated at the intersection of computer science, behavioral sciences, design, media studies, and several other fields of study.</p>
        <button class="btn"><i class="fa fa-download"></i> Go to Course page</button>
    </div>
        <br>
        <div class="course"><h1>Internet and Web Programming</h1>
        <p>Web development is a broad term for the work involved in developing a web site for the Internet (World Wide Web) or an intranet (a private network). Web development can range from developing the simplest static single page of plain text to the most complex web-based internet applications (or just 'web apps') electronic businesses, and social network services.</p>
        <button class="btn"><i class="fa fa-download"></i> Go to Course page</button></div>
        </div>

    <div id="rightcolumn">
        <br>
        <iframe width="450" height="370" src="https://www.youtube.com/embed/QSIPNhOiMoE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        <br>
        <br>
        <iframe width="450" height="350" src="https://www.youtube.com/embed/Zftx68K-1D4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        
    </div>
 
        </div>

    </div><!-- Main Col END -->
    
</div><!-- body-row END -->
  
  
</div><!-- container -->
<!-- partial -->
  <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script><script  src="sidebar/script.js"></script>

</body>
</html>