<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>TEACHER PROFILE</title>
</head>
<body>

</body>
</html>