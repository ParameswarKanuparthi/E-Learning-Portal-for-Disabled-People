<?php
$p=array();
$p['name']="adfn";
echo $p['name'];
?>