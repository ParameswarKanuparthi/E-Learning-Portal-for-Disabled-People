<?php
include "connection.php";
$str="vygvt";
$sql="CREATE TABLE ".$str." (akhil INT(10))";
mysqli_query($conn,$sql);
?>
