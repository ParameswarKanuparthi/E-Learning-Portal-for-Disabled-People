<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN HOME</title>
	<link rel="stylesheet" type="text/css" href="acc.css">
</head>
<body>
	<div id="top">
	<img src="logo.png">
	<h2 class="wel"> WELCOME ADMIN</h2><br><br><br><br>
	<a href="adminlog.php" class="wel">LOGOUT</a><br>
	</div><br><br>
	<ul>
<li><a href="addcourse.php">ADD COURSE</a><br></li>
<li><a href="selectteacher.php">SELECT TEACHER</a><br></li>
</ul>
</body>
</html>
