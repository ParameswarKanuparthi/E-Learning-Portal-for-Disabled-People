<?php
include 'connection.php';
if (isset($_POST['submit'])) {
	$ud=$_POST['username'];
	$pwd=$_POST['pwd'];
	if(empty($ud)||empty($ud))
	{
		echo "<script>alert('empty fields detected');</script>";

	}
	else
	{
		if(strcmp($ud,"admin")==0 && strcmp($pwd, "admin")==0)
		{
			echo "<script>window.location='adminhome.php';</script>";
		}
		else
		{
			echo "<script>alert('invalid user credentials');</script>";
		}
	}
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">   
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="Login/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Login/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Login/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login/css/util.css">
	<link rel="stylesheet" type="text/css" href="Login/css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('Login/images/bg-01.jpg');">
			<div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">	
				Admin Login
				</span>
				<form method="post" action="adminlog.php" class="login100-form validate-form p-b-33 p-t-5">

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="username" placeholder="User name">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="pwd" placeholder="Password">
						<span class="focus-input100" data-placeholder="&#xe80f;"></span>
					</div>

					<div class="container-login100-form-btn m-t-32">
						<button class="login100-form-btn" name="submit" id="sub">
							Login
						</button>
					</div>

				</form>
			</div>
			<p id="emp"> </p>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="Login/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="Login/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="Login/vendor/bootstrap/js/popper.js"></script>
	<script src="Login/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="Login/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="Login/vendor/daterangepicker/moment.min.js"></script>
	<script src="Login/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="Login/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="Login/js/main.js"></script>

</body>
</html>

<!-- 

    <!DOCTYPE html>
<html>
<head>
    <title>Startup</title>
    <link rel="stylesheet" type="text/css" href="style3.css">
    
</head>
<body>
<div id="header">
<img src="logo.png" id="logo">
<h1 id="title" tabindex="1">GRAV INSTITUTIONS</h1>  

</div>
<div class="container" >
    <div id="leftcolumn">
        <div id="menu" style="height: 350px;">
            <div id="empty"></div>

                <div id="dedulog" >
                    <a href="startup_stu_login.php" tabindex="2.1">Student Login</a></div>
                
                <div id="teacherlog" >
                    <a href="startup_teach_login.php" tabindex="2.2">Teacher Login</a></div>
                
                <div id="studentsignup" >
                    <a href="startup_stu_sign.php" tabindex="2.4">Student signup</a></div>

                <div id="teachersignup" >
                    <a href="startup_teach_sign.php" tabindex="2.3">Teacher signup</a></div>

                <div id="admin" style="padding: 10px; margin: 20px;background-color: white;font-size: 20px;">
                    <a href="adminlog.php" tabindex="2.5">Admin Login</a></div>
                
                
        </div>
    </div>
<div id="column">

<center>
	<h1>ADMIN LOGIN</h1><br><br><br>
	<form action="adminlog.php" method="post">
		<table>
			<tr>
				<th>USERNAME:</th>
				<td><input type="text" name="username"></td>
			</tr>
			<tr>
				<th>PASSWORD:</th>
				<td><input type="password" name="pwd"></td>
			</tr>
			<tr>
				<th colspan="2" align="center"><input type="submit" name="submit"></th>
			</tr>
		</table>
		
	</form>
</center>
       
</div>

<div id="bottom">
    <a href="about.html">ABOUT US</a><br><br>
    <a href="contact.html" id="contact">CONTACT US</a>
</div>

</body>
</html> -->