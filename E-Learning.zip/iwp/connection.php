<?php
 $u="localhost";
 $s="root";
 $pas="";
 $db="iwp";
 $conn=mysqli_connect($u,$s,$pas,$db);
 
?>