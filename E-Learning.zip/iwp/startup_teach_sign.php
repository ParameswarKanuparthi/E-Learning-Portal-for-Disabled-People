    <!-- <!DOCTYPE html>
<html>
<head>
    <title>Startup</title>
    <link rel="stylesheet" type="text/css" href="style3.css">
    
</head>
<body>
<div id="header">
<img src="logo.png" id="logo">
<h1 id="title" tabindex="1">GRAV INSTITUTIONS</h1>  

</div>
<div class="container" >
    <div id="leftcolumn">
        <div id="menu" style="height: 350px;">
            <div id="empty"></div>

                <div id="dedulog" >
                    <a href="startup_stu_login.php" tabindex="2.1">Student Login</a></div>
                
                <div id="teacherlog" >
                    <a href="startup_teach_login.php" tabindex="2.2">Teacher Login</a></div>
                
                <div id="studentsignup" >
                    <a href="startup_stu_sign.php" tabindex="2.4">Student signup</a></div>

                <div id="teachersignup" >
                    <a href="startup_teach_sign.php" tabindex="2.3">Teacher signup</a></div>

                <div id="admin" style="padding: 10px; margin: 20px;background-color: white;font-size: 20px;">
                    <a href="adminlog.php" tabindex="2.5">Admin Login</a></div>
                
                
        </div>
    </div>
<div id="column"> -->

<?php
 $u="localhost";
 $s="root";
 $pas="";
 $db="iwp";
 $conn=mysqli_connect($u,$s,$pas,$db);
if(isset($_POST['REGISTER']))
{
    
    if(empty($_POST['name']) || empty($_POST['age']) || empty($_POST['dob']) || empty($_POST['pass']) || empty($_POST['pass2'])  )
    {
        echo "<script>alert('Please enter all the fields');</script>";
    }
    else 
    {
        $name=$_POST["name"];$age=$_POST["age"];$dob=$_POST["dob"];$pass=$_POST["pass"];$uname=$_POST["uname"];$pass2=$_POST["pass2"];
        $p="8699";$e="0";
        $sql2="SELECT * FROM teacher WHERE USERNAME='$uname';";
        $result=mysqli_query($conn,$sql2);
        
        if(mysqli_num_rows($result)!=0)
        {
            echo "<script>alert('Username already exists!');</script>";
        }
        else
        {
            if(strcmp($pass, $pass2)!=0)
            {
                echo "<script>alert('PLEASE TYPE SAME PASSWORDS');</script>";   
                

            }
            else
            {
                $sql="INSERT INTO TEACHER(NAME,AGE,USERNAME,PASSWORD,DOB) VALUES ('$name','$age','$uname','$pass','$dob');";
                mysqli_query($conn,$sql);               
            }
        }
    }
    
}
?>
<!-- <!DOCTYPE html>
<html>
<head>
    <title>SIGN UP</title>
    
    <script type="text/javascript">
        function analysis()
        {
            var s= document.getElementById('sc');
            alert(s.value);
        }
    </script>
</head>
<body>
    <h1 align="center"> SIGNUP FOR TEACHERS</h1>
<CENTER><form action="teachersignup.php" method="post">
    <table>
    <tr><th>NAME: </th><td><input type="text" name="name"></td></tr>
    <tr><th>AGE: </th><td><input type="text" name="age"></td></tr>
    <tr><th>USERNAME: </th><td><input type="text" name="uname"></td></tr>
    <tr><th>DOB: </th><td><input type="text" name="dob"></td></tr>
    <tr><th>PASSWORD:</th><td><input type="password" name="pass"></td></tr>
    <tr><th>CONFIRM PASSWORD:</th><td> <input type="password" name="pass2"></td></tr>
    </table>
    <br>
    <input type="submit" value="REGISTER" name="REGISTER">
</form></CENTER>
</body>
</html>
       
</div>

<div id="bottom">
    <a href="about.html">ABOUT US</a><br><br>
    <a href="contact.html" id="contact">CONTACT US</a>
</div>

</body>
</html> -->





<?php
 $u="localhost";
 $s="root";
 $pas="";
 $db="iwp";
 $conn=mysqli_connect($u,$s,$pas,$db);
if(isset($_POST['REGISTER']))
{
  
  if(empty($_POST['name']) || empty($_POST['age']) || $_POST['type']=="-" || empty($_POST['dob']) || empty($_POST['pass']) || empty($_POST['pass2'])  )
  {
    echo "<script>alert('Please enter all the fields');</script>";
  }
  else 
  {
    $name=$_POST["name"];$age=$_POST["age"];$type=$_POST["type"];$dob=$_POST["dob"];$pass=$_POST["pass"];$uname=$_POST["uname"];$pass2=$_POST["pass2"];
    $p="8699";$e="0";
    $sql2="SELECT * FROM STUDENT WHERE USERNAME='$uname';";
      $result=mysqli_query($conn,$sql2);
      
      if(mysqli_num_rows($result)!=0)
      {
        echo "<script>alert('Username already exists!');</script>";
      }
    else
    {
      if(strcmp($pass, $pass2)!=0)
      {
        echo "<script>alert('PLEASE TYPE SAME PASSWORDS');</script>"; 
        

      }
      else
      {
        $sql="INSERT INTO STUDENT(NAME,AGE,TYPE,USERNAME,PASSWORD,DOB,COURSES) VALUES ('$name','$age','$type','$uname','$pass','$dob','$e');";
        mysqli_query($conn,$sql);       
      }
    }
  }
  
}
?>




<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Teacher Signup</title>
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'><link rel="stylesheet" href="sidebar/style.css">
<link rel="stylesheet" type="text/css" href="style3.css">
<script type="text/javascript">
        function analysis()
        {
            var s= document.getElementById('sc');
            alert(s.value);
        }
    </script>
</head>
<body>
<!-- partial:index.partial.html -->
<div class="container-fluid p-0">
  
<!-- Bootstrap row -->
<div class="row" id="body-row">
    <!-- Sidebar -->
    <div id="sidebar-container" class="sidebar-expanded d-none d-md-block"><!-- d-* hiddens the Sidebar in smaller devices. Its itens can be kept on the Navbar 'Menu' -->
        <!-- Bootstrap List Group -->
        <ul class="list-group">
            <!-- Separator with title -->
            <li class="list-group-item sidebar-separator-title text-muted d-flex align-items-center menu-collapsed">
                <small>MAIN MENU</small>
            </li>
            <!-- /END Separator -->
            <!-- Menu with submenu -->
            <a href="index.html" class="bg-dark list-group-item list-group-item-action">
                <div class="d-flex w-100 justify-content-start align-items-center">
                    <span class="fa fa-tasks fa-fw mr-3"></span>
                    <span class="menu-collapsed">Home</span>    
                </div>
            </a>
            <a href="#submenu1" data-toggle="collapse" aria-expanded="false" class="bg-dark list-group-item list-group-item-action flex-column align-items-start">
                <div class="d-flex w-100 justify-content-start align-items-center">
                    <span class="fa fa-dashboard fa-fw mr-3"></span> 
                    <span class="menu-collapsed">Teacher</span>
                    <span class="submenu-icon ml-auto"></span>
                </div>
            </a>
            <!-- Submenu content -->
            <div id='submenu1' class="collapse sidebar-submenu">
                <a href="teacherlog.php" class="list-group-item list-group-item-action bg-dark text-white">
                    <span class="menu-collapsed">Teacher Login</span>
                </a>
                <a href="startup_teach_sign.php" class="list-group-item list-group-item-action bg-dark text-white">
                    <span class="menu-collapsed">Teacher Signup</span>
                </a>
            </div>
            <a href="#submenu2" data-toggle="collapse" aria-expanded="false" class="bg-dark list-group-item list-group-item-action flex-column align-items-start">
                <div class="d-flex w-100 justify-content-start align-items-center">
                    <span class="fa fa-user fa-fw mr-3"></span>
                    <span class="menu-collapsed">Student</span>
                    <span class="submenu-icon ml-auto"></span>
                </div>
            </a>
            <!-- Submenu content -->
            <div id='submenu2' class="collapse sidebar-submenu">
                <a href="startup_stu_login.php" class="list-group-item list-group-item-action bg-dark text-white">
                    <span class="menu-collapsed">Student Login</span>
                </a>
                <a href="startup_stu_sign.php " class="list-group-item list-group-item-action bg-dark text-white">
                    <span class="menu-collapsed">Student Signup</span>
                </a>
            </div>            
            <a href="adminlog.php" class="bg-dark list-group-item list-group-item-action">
                <div class="d-flex w-100 justify-content-start align-items-center">
                    <span class="fa fa-tasks fa-fw mr-3"></span>
                    <span class="menu-collapsed">Admin Login</span>    
                </div>
            </a>
           
    </div><!-- sidebar-container END -->

    <!-- MAIN -->
    <div class="col">
    <div id="header">
<img src="logo.png" id="logo">
<h1 id="title" tabindex="1">GRAV INSTITUTIONS</h1>  

</div>


<br><br><br><br>
        
    <h1 align="center"> SIGNUP FOR TEACHERS</h1>
<CENTER><form action="teachersignup.php" method="post">
    <table>
    <tr><th>NAME: </th><td><input type="text" name="name"></td></tr>
    <tr><th>AGE: </th><td><input type="text" name="age"></td></tr>
    <tr><th>USERNAME: </th><td><input type="text" name="uname"></td></tr>
    <tr><th>DOB: </th><td><input type="date" name="dob"></td></tr>
    <tr><th>PASSWORD:</th><td><input type="password" name="pass"></td></tr>
    <tr><th>CONFIRM PASSWORD:</th><td> <input type="password" name="pass2"></td></tr>
    </table>
    <br>
    <input type="submit" value="REGISTER" name="REGISTER">
</form></CENTER>
       


    </div><!-- Main Col END -->
    
</div><!-- body-row END -->
  
  
</div><!-- container -->
<!-- partial -->
  <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script><script  src="sidebar/script.js"></script>

</body>
</html>